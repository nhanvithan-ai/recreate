---
name: Forge Premium
colors:
  surface: '#19120a'
  surface-dim: '#19120a'
  surface-bright: '#41382e'
  surface-container-lowest: '#140d06'
  surface-container-low: '#221a12'
  surface-container: '#261e15'
  surface-container-high: '#31281f'
  surface-container-highest: '#3c3329'
  on-surface: '#f0e0d1'
  on-surface-variant: '#d8c3ad'
  inverse-surface: '#f0e0d1'
  inverse-on-surface: '#382f25'
  outline: '#a08e7a'
  outline-variant: '#534434'
  surface-tint: '#ffb95f'
  primary: '#ffc174'
  on-primary: '#472a00'
  primary-container: '#f59e0b'
  on-primary-container: '#613b00'
  inverse-primary: '#855300'
  secondary: '#fcb973'
  on-secondary: '#492900'
  secondary-container: '#6c3e00'
  on-secondary-container: '#ecab67'
  tertiary: '#8fd5ff'
  on-tertiary: '#00344a'
  tertiary-container: '#1abdff'
  on-tertiary-container: '#004966'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb8'
  primary-fixed-dim: '#ffb95f'
  on-primary-fixed: '#2a1700'
  on-primary-fixed-variant: '#653e00'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#fcb973'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#683c00'
  tertiary-fixed: '#c5e7ff'
  tertiary-fixed-dim: '#7fd0ff'
  on-tertiary-fixed: '#001e2d'
  on-tertiary-fixed-variant: '#004c6a'
  background: '#19120a'
  on-background: '#f0e0d1'
  surface-variant: '#3c3329'
typography:
  display-lg:
    fontFamily: Lexend
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Lexend
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Lexend
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.01em
  data-tabular:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  gutter: 16px
  margin: 20px
---

## Brand & Style

This design system is engineered for the high-performance athlete who values precision and quiet confidence over loud, gamified aesthetics. The brand personality is authoritative yet empowering, functioning more like a high-end piece of gym equipment or a luxury timepiece than a typical social app. 

The visual style blends **Modern Minimalism** with subtle **Glassmorphism**. By prioritizing deep blacks and rich ambers, the UI creates a focused "dark room" environment that reduces ocular strain during workouts while highlighting critical performance data. The atmosphere is intended to be calm and professional, removing digital noise to help the user focus on their physical form and progress.

## Colors

The palette is anchored in a triple-layered dark neutral system to establish depth without relying on traditional shadows. 

- **Background:** The deepest layer, providing a solid foundation for all content.
- **Surface & Elevated:** Used to distinguish content hierarchy; cards sit on the surface, while interactive floating elements or modals use the elevated tone.
- **Accents:** The Amber (#F59E0B) is used exclusively for primary actions and "active" states (e.g., a timer running, a completed set). The Secondary Accent (#FDBA74) is reserved for data visualization highlights and subtle secondary cues.
- **Typography:** High-contrast whites and greys ensure legibility in low-light gym environments.

## Typography

This design system employs a dual-font strategy to balance athletic energy with technical clarity. **Lexend** is utilized for headlines and display text, leveraging its rhythmic, hyper-readable structure to convey a sense of movement and strength. 

**Inter** is the workhorse for all body text, inputs, and data points. Its neutral, systematic nature ensures that complex workout statistics—such as heart rate, reps, and tonnage—remain the focal point. Use `data-tabular` for numerical values within workout logs to ensure maximum visibility at a glance.

## Layout & Spacing

The layout philosophy follows a **fluid grid** model with a focus on generous vertical breathing room. Elements are organized on an 8px rhythmic scale to maintain mathematical harmony.

On mobile devices, a 20px side margin is maintained to prevent content from feeling cramped against device edges. Gutters are fixed at 16px to ensure distinct separation between data cards. For high-density workout views, the `sm` (12px) spacing unit should be used to group related metrics together, while `2xl` (48px) should be used to separate major sections like "Today's Routine" from "Progress Trends."

## Elevation & Depth

Visual hierarchy in this design system is achieved through **tonal layering** and **subtle glassmorphism**. Rather than using heavy drop shadows, which can feel cluttered in dark modes, depth is indicated by lightening the background hex of the element as it "rises" toward the user.

- **Level 0 (Background):** #1C1C1C.
- **Level 1 (Cards):** #2A2A2A with a subtle 1px border (#3D3D3D) to define edges.
- **Level 2 (Modals/Overlays):** #333333 with a background blur (8px to 12px) and 60% opacity to create a frosted glass effect.

Use a very soft, diffused amber glow (opacity 10-15%) behind primary buttons to simulate a premium light-emissive quality.

## Shapes

The shape language is defined by **refined roundness**. Standard components use a 12px (`0.75rem`) radius to feel approachable yet modern. 

- **Small Components (Chips/Badges):** 8px radius.
- **Standard Containers (Cards/Inputs):** 16px radius for a distinctively "soft-tech" feel.
- **Full Rounding:** Reserved exclusively for progress bars and specific "Pill" toggle buttons to indicate movement and fluidity.

Avoid sharp 0px corners entirely, as they contradict the "empowering" brand pillar.

## Components

### Buttons
Primary buttons use the Amber (#F59E0B) fill with black text for maximum contrast. Secondary buttons use a ghost style with a 1px #F59E0B border. State changes (hover/active) should involve a slight scale-down (98%) to provide tactile feedback.

### Cards
Cards are the primary container for workout data. They must use the #2A2A2A background. For AI-generated insights, use a subtle gradient border transition between Primary and Secondary accents to signify the "intelligence" layer.

### Input Fields
Fields should have a #333333 background with a 1px #444444 border. On focus, the border transitions to #F59E0B. Labels sit above the field in `label-md` secondary text.

### Chips & Tags
Used for muscle groups or equipment types. They should be low-profile, using the #333333 background with `body-sm` text. Only the "Selected" state should utilize the Primary Accent.

### Progress Elements
Workout progress should be tracked using thick, rounded stroke bars. The background track should be #333333, and the active progress should be a gradient from #F59E0B to #FDBA74 to represent energy and heat.